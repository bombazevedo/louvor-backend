const express = require('express');
const router = express.Router();

// Mock de eventos
const events = [
  { id: '1', title: 'Culto de Louvor', date: '2024-05-01', location: 'Igreja Central' },
  { id: '2', title: 'Ensaio', date: '2024-05-05', location: 'Salão B' }
];

// Listar todos eventos
router.get('/', (req, res) => {
  res.status(200).json(events);
});

// Buscar evento por ID
router.get('/:id', (req, res) => {
  const event = events.find(e => e.id === req.params.id);
  if (event) {
    res.json(event);
  } else {
    res.status(404).json({ message: 'Evento não encontrado' });
  }
});

module.exports = router;

module.exports = {
  secret: "Z9qTjKxG2rVuY7NdWfLpBaXmE6CvRs1tMjQoH3UzAgPkIbXnFyDhLeTwVsJnCrGy", // usada para autenticação JWT
  db: {
    uri: "mongodb+srv://bombazevedo7:<33268230>@cluster0.cxr783x.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0" // ou outro banco configurado
  }
};
